


    
    <?php include 'head.php'; ?>
    <?php  include "header.php"; ?>
    <div class="container">
        <div class="side-menu">
            <a href="pedido.php">
                <div class="item">
                    <div>
                        <span>Pedidos</span>
                    </div>
                    <div class="barra-horizontal"></div>
                </div>
            </a>

            <a href="dados.php">
                <div class="item">
                    <div>
                        <span>Seus dados</span>
                    </div>
                    <div class="barra-horizontal"></div>
                </div>
            </a>

            <a href="endereco.php">
                <div class="item">
                    <div>
                        <span>Endereço</span>
                    </div>
                    <div class="barra-horizontal"></div>
                </div>
            </a>

            <a href="">
                <div class="item">
                    <div>
                        <span>Sair</span>
                    </div>
                </div>
            </a>
        </div>
    </div>
</body>

</html>