<div class="p-15 p-b-0">
                                <form class="form-material" method="get" action="">
                                    <div class="form-group form-primary">
                                        <input type="text" name="Pesquisa" class="form-control">
                                        <span class="form-bar"></span>
                                        <label class="float-label"><i class="fa fa-search m-r-10"></i>Pesquisar produto...</label>
                                    </div>
                                </form>
                            </div>