

    $('.carousel').slick({
        arrows: false,
        dots: true,
        infinite: true,
        speed: 300,
        autoplay: true,
        autoplaySpeed: 2000,
    });
