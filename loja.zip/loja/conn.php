<?php

$conn = new mysqli("162.241.2.204", "divasp33_master", "qRfWMk6VYqJyW8B", "divasp33_store");

// $conn = new mysqli("localhost", "root", "", "store");

// $conn = new mysqli("localhost", "divasp33_master", "qRfWMk6VYqJyW8B", "divasp33_store");

mysqli_set_charset($conn, 'utf8mb4');

?>